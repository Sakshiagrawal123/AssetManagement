package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.Asset;
import com.cg.dto.AssetAllocation;
import com.cg.exception.AssetException;

public interface ManagerService 
{

	public int raiseRequest(AssetAllocation assetAlloc)throws AssetException;
	public String checkStatus(int allocId);
	public boolean validateAssetId(int id);
	public boolean validateEmpId(int id);
	public boolean validateDate(String d);
	public ArrayList<Asset> displayAllAssets();
	public boolean validateQuantity(int quantity,int id);
	public int getQuantity(int id);
}
