package com.cg.service;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.dao.ManagerDAO;
import com.cg.dao.ManagerDAOImpl;
import com.cg.dto.Asset;
import com.cg.dto.AssetAllocation;
import com.cg.exception.AssetException;

public class ManagerServiceImpl implements ManagerService
{

	ManagerDAO ref=null;
	Logger managerServiceLogger=null;
	
	public ManagerServiceImpl()
	{
		ref=new ManagerDAOImpl();
		managerServiceLogger=Logger.getLogger(ManagerServiceImpl.class);
		PropertyConfigurator.configure("log4j.properties");
	}

	@Override
	public int raiseRequest(AssetAllocation assetAlloc) throws AssetException
	{
		return ref.raiseRequest(assetAlloc);
	}

	@Override
	public String checkStatus(int allocId) 
	{
		return ref.checkStatus(allocId);
	}

	@Override
	public boolean validateAssetId(int id) 
	{
		 ArrayList<Integer> list = new ArrayList<Integer>();
	        list = ref.displayAllAssetId();
	        if(list.contains(id)) 
	        {
	        	managerServiceLogger.info("Entered Asset ID validation successful!!!");
	        	return true;
	        }
	        else 
	        {
	        	managerServiceLogger.info("Entered Asset ID validation unsuccessful!!!");
	        	return false;
	        }	
	}

	@Override
	public boolean validateEmpId(int id) 
	{
		ArrayList<Integer> list = new ArrayList<Integer>();
        list = ref.displayAllEmpNo();
        if(list.contains(id))
        {
        	managerServiceLogger.info("Entered Employee ID validation successful!!!");
        	return true;
        }
        else
        {
        	managerServiceLogger.info("Entered Employee ID validation unsuccessful!!!");
        	return false;
        }
	}

	@Override
	public boolean validateDate(String d) 
	{
	
		 String DATE_REGEX = "(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)";
		 Pattern pattern = Pattern.compile(DATE_REGEX);
		 Matcher matcher = pattern.matcher(d);
		 if (matcher.matches())
		 {

		  matcher.reset();

		  if (matcher.find())
		  {

		  String day = matcher.group(1);
		  String month = matcher.group(2);
		  int year = Integer.parseInt(matcher.group(3));

		  if (day.equals("31") && (month.equals("4") || month.equals("6")
		   || month.equals("9") || month.equals("11")
		   || month.equals("04") || month.equals("06")
		   || month.equals("09")))
		  {
			  managerServiceLogger.info("Entered Date validation unsuccessful!!!");
		   return false; // only 1,3,5,7,8,10,12 has 31 days
		  }
		  else if (month.equals("2") || month.equals("02"))
		   {
		   // leap year
		   if (year % 4 == 0)
		   {
		   if (day.equals("30") || day.equals("31"))
		   {
			   managerServiceLogger.info("Entered Date validation unsuccessful!!!");
		    return false;
		   }
		   else
		   {
			   managerServiceLogger.info("Entered Date validation successful!!!");
		    return true;
		   }
		   }
		   else
		   {
		   if (day.equals("29") || day.equals("30")
		    || day.equals("31"))
		   {
			   managerServiceLogger.info("Entered Date validation unsuccessful!!!");
		    return false;
		   }
		   else
		   {
			   managerServiceLogger.info("Entered Date validation successful!!!");
		    return true;
		   }
		   }
		  }
		  else
		  {
			  managerServiceLogger.info("Entered Date validation successful!!!");
		   return true;
		  }
		  }
		  else
		  {
			  managerServiceLogger.info("Entered Date validation unsuccessful!!!");
		  return false;
		  }
		 }
		 else
		 {
			 managerServiceLogger.info("Entered Date validation unsuccessful!!!");
		  return false;
		 }
	}

	@Override
	public ArrayList<Asset> displayAllAssets()
	{
		
		return ref.displayAllAssets();
	}

	@Override
	public boolean validateQuantity(int quantity,int id)
	{
		int assetQuant=ref.getQuantity(id);
		if(quantity>assetQuant)
			return false;

		else
			return true;
	}

	@Override
	public int getQuantity(int id) 
	{
		
		return ref.getQuantity(id);
	}

}
