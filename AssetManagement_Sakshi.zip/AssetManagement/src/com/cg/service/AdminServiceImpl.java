package com.cg.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.dao.AdminDAO;
import com.cg.dao.AdminDAOImpl;
import com.cg.dto.Asset;
import com.cg.dto.AssetAllocation;
import com.cg.dto.UserMaster;
import com.cg.exception.AssetException;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class AdminServiceImpl implements AdminService {
	
	AdminDAO ref=null;
	Logger adminServiceLogger=null;
	public AdminServiceImpl()
	{
		ref=new AdminDAOImpl();
		adminServiceLogger=Logger.getLogger(AdminServiceImpl.class);
		PropertyConfigurator.configure("log4j.properties");
	}

	@Override
	public ArrayList<AssetAllocation> displayAllAssetRequest()
			throws AssetException
	{
		
		return ref.displayAllAssetRequest();
	}

	@Override
	public UserMaster getUser(String userName, String userPassword) throws AssetException
	{
		
		return ref.getUser(userName, userPassword);
	}

	@Override
	public int addAsset(Asset asset)  throws AssetException
	{
		
		return ref.addAsset(asset);
	}

	@Override
	public int updateStatus(String str,int choice)  throws AssetException
	{
		
		return ref.updateStatus(str,choice);
	}

	@Override
	public int updateAsset(Asset asset)  throws AssetException
	{
		return ref.updateAsset(asset);
	}

	@Override
	public ArrayList<AssetAllocation> showRequestList(String str) throws AssetException 
	{
		return ref.showRequestList(str);
	}

	@Override
	public void exportAssetStatus() throws AssetException 
	{
		
		 ref.exportAssetStatus();
	}

	@Override
	public boolean validateAssetName(String assetName)
	{
		String assetNamePattern = "[A-Z][a-zA-Z][a-zA-Z]+";
		
		if(Pattern.matches(assetNamePattern, assetName))
		{
			adminServiceLogger.info("Asset name validation successful!!!");
			return true;
		
		}
		else
		{
			adminServiceLogger.info("Asset name validation unsuccessful!!!");
			return false;
		}
	}

	@Override
	public boolean validateAssetDesc(String assetDesc)
	{
		String assetDescPattern = "[a-zA-Z0-9]{3,}";
		if(Pattern.matches(assetDescPattern, assetDesc))
		{
			adminServiceLogger.info("Asset description validation successful!!!");
			return true;
		}
		else
		{
			adminServiceLogger.info("Asset description validation unsuccessful!!!");
			return false;
		}
		
	}

	@Override
	public boolean validateQuantity(int quantity) 
	{
		if(quantity > 0)
		{
			adminServiceLogger.info("Entered valid quantity !!!");
			return true;
		}
		else
		{
			adminServiceLogger.info("Entered quantity less than 0!!!");
			return false;
		}
	}

	@Override
	public boolean validateStatus(String assetStatus) 
	{
		
		if(assetStatus.equalsIgnoreCase("Avaliable") || assetStatus.equalsIgnoreCase("Not Avaliable"))
		{
			adminServiceLogger.info("Entered valid status (Available/Unavailable)!!!");
			return true;
		}
		else
		{
			adminServiceLogger.info("Entered invalid status!!!");
			return false;
		}
	}

	@Override
	public int updateQuantity() throws AssetException 
	{
		return ref.updateQuantity();
	}

}
