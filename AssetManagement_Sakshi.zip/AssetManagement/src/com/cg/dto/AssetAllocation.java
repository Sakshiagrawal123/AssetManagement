package com.cg.dto;

import java.sql.Date;

public class AssetAllocation {
	
	private int allocationId;
	private int assetId;
	private int empNo;
	private Date allocationDate;
	private Date releaseDate;
	private String allocationStatus;
	private int quantity;
	public AssetAllocation(int allocationId, int assetId, int empNo, Date allocationDate, Date releaseDate,
			String allocationStatus, int quantity) {
		super();
		this.allocationId = allocationId;
		this.assetId = assetId;
		this.empNo = empNo;
		this.allocationDate = allocationDate;
		this.releaseDate = releaseDate;
		this.allocationStatus = allocationStatus;
		this.quantity = quantity;
	}
	public AssetAllocation(int assetId, int empNo, Date allocationDate, Date releaseDate, int quantity) {
		super();
		this.assetId = assetId;
		this.empNo = empNo;
		this.allocationDate = allocationDate;
		this.releaseDate = releaseDate;
		this.quantity = quantity;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public AssetAllocation(int assetId, int empNo, Date allocationDate, Date releaseDate) {
		super();
		this.assetId = assetId;
		this.empNo = empNo;
		this.allocationDate = allocationDate;
		this.releaseDate = releaseDate;
	}
	public AssetAllocation(int allocationId, int assetId, int empNo, Date allocationDate, Date releaseDate,
			String allocationStatus) {
		super();
		this.allocationId = allocationId;
		this.assetId = assetId;
		this.empNo = empNo;
		this.allocationDate = allocationDate;
		this.releaseDate = releaseDate;
		this.allocationStatus = allocationStatus;
	}
	public String getAllocationStatus() {
		return allocationStatus;
	}
	public void setAllocationStatus(String allocationStatus) {
		this.allocationStatus = allocationStatus;
	}
	public AssetAllocation() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AssetAllocation(int allocationId, int assetId, int empNo,
			Date allocationDate, Date releaseDate) {
		super();
		this.allocationId = allocationId;
		this.assetId = assetId;
		this.empNo = empNo;
		this.allocationDate = allocationDate;
		this.releaseDate = releaseDate;
	}
	@Override
	public String toString() {
		return "AssetAllocation [allocationId=" + allocationId + ", assetId=" + assetId + ", empNo=" + empNo
				+ ", allocationDate=" + allocationDate + ", releaseDate=" + releaseDate + ", allocationStatus="
				+ allocationStatus + ", quantity=" + quantity + "]";
	}
	public int getAllocationId() {
		return allocationId;
	}
	public void setAllocationId(int allocationId) {
		this.allocationId = allocationId;
	}
	public int getAssetId() {
		return assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public Date getAllocationDate() {
		return allocationDate;
	}
	public void setAllocationDate(Date allocationDate) {
		this.allocationDate = allocationDate;
	}
	public Date getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}
	

}

