package com.cg.ui;


import java.util.Scanner;
import com.cg.dto.UserMaster;
import com.cg.exception.AssetException;
import com.cg.service.AdminService;
import com.cg.service.AdminServiceImpl;
import com.cg.service.ManagerService;
import com.cg.service.ManagerServiceImpl;

public class MainClass {

	static Scanner sc=new Scanner(System.in);
	static  AdminService adminService=null;
	public static void main(String[] args)
	{
		
		adminService=new AdminServiceImpl();
		
		boolean flag=true;
		do
		{
	    System.out.println("--------------------LOGIN--------------------");
		System.out.println("Enter the username : ");
		String username=sc.next();
		System.out.println("Enter the password : ");
		String password=sc.next();
		try 
		{
			UserMaster user=adminService.getUser(username, password);
			if(user.getUserType().equals("Manager"))
			{
				System.out.println("----------Manager Operations----------");
				int choice=0;
				while(true)
				{
					System.out.println("What do you want to do?");
					System.out.println("1 : Raise a request  \n2 : See the status of the request\n"+
					                   "3 : Logout \n"+"4 : Exit \n" );
					                  
					choice=sc.nextInt();
					switch(choice)
					{
					case 1: FunctionImplementation.raiseRequest();break;
					case 2: FunctionImplementation.checkStatus();break;
					case 3:MainClass.main(null);break;
					default:System.exit(1);
					}
				}
				
			}
			else if(user.getUserType().equals("Admin"))
			{
				adminService.updateQuantity();
				System.out.println("----------Admin Operations----------");
				int choice=0;
				while(true)
				{
					System.out.println("What do you want to do?");
					System.out.println("1 : Add an asset \n2 : Modify an asset\n3 : Display all requests\n"+
			                   "4 : Display approved requests \n5 : Display rejected requests"
			                   + "\n6 : Display pending requests"+"\n7 : Export data"
			                   + "\n8 : Logout \n"+"9 : Exit \n" );
					                  
					choice=sc.nextInt();
					switch(choice)
					{
					case 1: FunctionImplementation.addRequest();break;
					case 2: FunctionImplementation.modifyRequest();break;
					case 3: FunctionImplementation.displayRequests();break;
					case 4: FunctionImplementation.showRequestList("Allocated");break;
					case 5: FunctionImplementation.showRequestList("Unallocated");break;
					case 6: FunctionImplementation.showRequestList("Pending");break;
					case 7: FunctionImplementation.exportData();break;
					case 8: MainClass.main(null);break;
					default:System.exit(1);
					}
				}
			}
		} 
		catch (AssetException e)
		{
			
			System.out.println(e.getMessage());
		}
		}while(flag!=false);
		
	}
	
}
