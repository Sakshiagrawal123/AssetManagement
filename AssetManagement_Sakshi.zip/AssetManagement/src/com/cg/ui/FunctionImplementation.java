package com.cg.ui;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.dto.Asset;
import com.cg.dto.AssetAllocation;
import com.cg.exception.AssetException;
import com.cg.service.AdminService;
import com.cg.service.AdminServiceImpl;
import com.cg.service.ManagerService;
import com.cg.service.ManagerServiceImpl;

public class FunctionImplementation 
{
	static Scanner sc=new Scanner(System.in);
	static AdminService adminService=new AdminServiceImpl();
	static ManagerService managerService=new ManagerServiceImpl();
	
	

	


	public static void raiseRequest()
	{
		int assetId;
		int empNo;
		Date allocDate;
		Date releaseDate;
		ArrayList<Asset> list=managerService.displayAllAssets();
		System.out.println("--------------List of all assets--------------");
		System.out.println();
		for(Asset asset:list)
		{
			System.out.println(asset);
			System.out.println();
		}
		System.out.println();
		while(true) 
		{
			System.out.println("Enter the asset id:");
			assetId=sc.nextInt();
			if(managerService.validateAssetId(assetId)==false) {
				System.out.println("Asset ID does not exist! Please enter correct ID");
			}
			else 
			{
				break;
			}
		}
		
		
		while(true) 
		{
			System.out.println("Enter the employee number :");
			empNo=sc.nextInt();
			if(managerService.validateEmpId(empNo)==false) 
			{
				System.out.println("Employee No. Does Not exist! Please Enter CorrectEmployee No.");
			}
			else 
			{
				break;
			}
		}
		while(true) 
		{
			System.out.println("Enter allocation date in dd/MM/yyyy :");
			String date1=sc.next();
			if(managerService.validateDate(date1)==false) 
			{
				System.out.println("Date Format Should be 'dd/MM/yyyy'");
			}
			else 
			{
				DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate date2=LocalDate.parse(date1, format);
				allocDate=Date.valueOf(date2);
				break;
			}
		}
        while(true)
        {
        	System.out.println("Enter release date in dd/MM/yyyy :");
    		String date4=sc.next();
    		if(managerService.validateDate(date4)==false) {
				System.out.println("Date Format Should be 'dd/MM/yyyy'");
			}
    		else {
    			DateTimeFormatter format1=DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate date5=LocalDate.parse(date4, format1);
				releaseDate=Date.valueOf(date5);
				break;
    		}
        }
		System.out.println("Enter the quantity:");
		int quantity=sc.nextInt();
		if(managerService.validateQuantity(quantity, assetId))
		{
			AssetAllocation asset=new AssetAllocation(assetId,empNo,allocDate,releaseDate,quantity);
			try
			{
				int id=managerService.raiseRequest(asset);
				System.out.println("Your request has been raised. The allocation id is : "+id);
			} 
			catch (AssetException e) 
			{
			
				System.out.println(e.getMessage());
			}
		}
		else
		{
			int assetQuantity=managerService.getQuantity(assetId);
			System.out.println("The available quantity is "+assetQuantity+" . The request for the remaining quantity will be approved after its availability");
			AssetAllocation asset=new AssetAllocation(assetId,empNo,allocDate,releaseDate,assetQuantity);
			try
			{
				int id=managerService.raiseRequest(asset);
				System.out.println("Your request has been raised. The allocation id is : "+id);
			} 
			catch (AssetException e) 
			{
			
				System.out.println(e.getMessage());
			}
		}
		
		
		
		
	}
	
	public static void checkStatus()
	{
		System.out.println("Enter the allocation Id :");
		int id=sc.nextInt();
		String status=managerService.checkStatus(id);
		if(status==null)
		{
			System.out.println("Enter proper allocation id");
		}
		else
		{
		System.out.println("Status of asset Allocation is : "+status);
		}
		
	}
	
	public static void addRequest() 
	{
		String assetName;
		String assetDesc;
		int assetQuantity;
		String assetStatus;
		while(true)
		{
			System.out.println("Enter the asset name :");
			assetName=sc.next();
			
			if(!adminService.validateAssetName(assetName))
			{
				System.out.println("Please Enter Proper Asset Name - MINIMUM 3 Letters AND SHOULD START WITH CAPITAL");
			}
			else
			{
				break;
			}
		}
		
		while(true)
		{
			System.out.println("Enter the asset description");
			assetDesc=sc.next();
			
			if(!adminService.validateAssetDesc(assetDesc))
			{
				System.out.println("Please Enter Proper Asset Desc - MINIMUM 5, No Special Characters Allowed");
			}
			else
			{
				break;
			}
		}
		
		while(true)
		{
			System.out.println("Enter the asset quantity");
			assetQuantity = sc.nextInt();
			
			if(!adminService.validateQuantity(assetQuantity))
			{
				System.out.println("Please Enter Proper Asset Name : GREATER THAN ZERO");
			}
			else
			{
				break;
			}
		}
		
		while(true)
		{
			System.out.println("Enter the asset status");
			assetStatus=sc.next();
			
			if(!adminService.validateStatus(assetStatus))
			{
				System.out.println("Status Can Be : Avaliable OR Not Avaliable");
			}
			else
			{
				break;
			}
		}
		
		Asset asset=new Asset(assetName,assetDesc,assetQuantity,assetStatus);
		int data=0;
		try 
		{
			data = adminService.addAsset(asset);
		} 
		catch (AssetException e) 
		{
			
			e.printStackTrace();
		}
		if(data==1)
			System.out.println("Asset successfully added");
	}
	
	public static void displayRequests()
	{
		ArrayList<AssetAllocation> list;
		String str;
		String str2;
		try
		{
			list = adminService.displayAllAssetRequest();
			
			for(AssetAllocation asset :list)
			{
				System.out.println(asset);
				System.out.println();
			}
			System.out.println();
			int choice=0;
			boolean flag1=true;
			while(flag1)
			{
				System.out.println("What do you want to do?");
				System.out.println("1 : Approve the requests \n2 : Reject the requests\n3: Back\n ");
				           
				                  
				choice=sc.nextInt();
				switch(choice)
				{
				case 1: System.out.println("Enter the id's to be approved");
						str=sc.next();
						adminService.updateStatus(str,choice);
						break;
				case 2: System.out.println("Enter the id's to be rejected");
						str2=sc.next();
						adminService.updateStatus(str2,choice);
						break;
	
				default:flag1=false;
				}
			}
			
		} catch (AssetException e) 
		{
			
			System.out.println(e.getMessage());
		}
		
		
	}
	
	
	public static void modifyRequest() 
	{
		System.out.println("Enter the asset id you want to update:");
		int assetId=sc.nextInt();
		System.out.println("Please Enter Details to Update the Asset:");
		System.out.println("Enter the asset name :");
		String assetName=sc.next();
		System.out.println("Enter the asset description");
		String assetDesc=sc.next();
		System.out.println("Enter the asset quantity");
		int assetQuantity=sc.nextInt();
		System.out.println("Enter the asset status");
		String assetStatus=sc.next();
		
		Asset asset = new Asset(assetId,assetName,assetDesc,assetQuantity,assetStatus);
		int data=0;
		try 
		{
			data = adminService.updateAsset(asset);
		} 
		catch (AssetException e) 
		{
			System.out.println(e.getMessage());
		}
		if(data==1)
			System.out.println("Asset successfully Updated");
		
	}
	
	
	public static void showRequestList(String str) 
	{
		ArrayList<AssetAllocation> list;
		try
		{
			list = adminService.showRequestList(str);
			if(list.isEmpty())
				System.out.println("No requests to show.");
			for(AssetAllocation asset :list)
			{
				System.out.println(asset);
				System.out.println();
			}
			System.out.println();
			int choice=0;
			System.out.println("What do you want to do?");
			System.out.println("1 : Change request status \n2 : Go back\n");                  
			choice=sc.nextInt();
			switch(choice)
			{
			case 1 :if(str.equals("Allocated"))
					{	
						System.out.println("Enter the id's to be rejected");
						String str1=sc.next();
						adminService.updateStatus(str1,2);
						break;
					}
						
					else if(str.equals("Unallocated"))
					{	
						System.out.println("Enter the id's to be approved");
						String str1=sc.next();
						adminService.updateStatus(str1,1);
						break;
					}					
					else if(str.equals("Pending"))
					{
						while(true)
						{
							System.out.println("What do you want to do?");
							System.out.println("1 : Approve the requests \n2 : Reject the requests\n3 : Go back");
							           
							                  
							choice=sc.nextInt();
							switch(choice)
							{
							case 1: System.out.println("Enter the id's to be approved");
									String str2=sc.next();
									adminService.updateStatus(str,choice);
									break;
							case 2: System.out.println("Enter the id's to be rejected");
									str2=sc.next();
									adminService.updateStatus(str2,choice);
									break;
							case 3: return;
							default: System.out.println("Please enter a valid choice!!!");
							}
							break;
						}
					}
			case 2: return;
			default: System.out.println("Please enter a valid choice!!!");
			}
		} 
		catch (AssetException e) 
		{
			System.out.println(e.getMessage());
		}
		
	}
	
	
	public static void exportData() throws AssetException
	{
		adminService.exportAssetStatus();
	}

}
