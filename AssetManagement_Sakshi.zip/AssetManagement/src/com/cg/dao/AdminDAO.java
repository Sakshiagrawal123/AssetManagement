package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Asset;
import com.cg.dto.AssetAllocation;
import com.cg.dto.UserMaster;
import com.cg.exception.AssetException;

public interface AdminDAO {

	public ArrayList<AssetAllocation> displayAllAssetRequest() throws AssetException;
	public UserMaster getUser(String userName, String userPassword) throws AssetException;
	public int addAsset(Asset asset) throws AssetException;
	public int updateStatus(String str,int choice) throws AssetException;
	public int updateAsset(Asset asset) throws AssetException;
	public ArrayList<AssetAllocation> showRequestList(String str)throws AssetException;
	public void exportAssetStatus() throws AssetException;
	public int updateQuantity() throws AssetException;
	public ArrayList<Asset> displayAllAssets();
	//public Asset getAssetById(int id);
	
}
