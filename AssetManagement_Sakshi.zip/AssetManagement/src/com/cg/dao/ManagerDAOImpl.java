package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.dto.Asset;
import com.cg.dto.AssetAllocation;
import com.cg.exception.AssetException;
import com.cg.util.DBUtil;

public class ManagerDAOImpl  implements ManagerDAO
{

	Connection con=null;
	public ManagerDAOImpl()
	{
		con=DBUtil.getConnection();
	}

	
	@Override
	public int raiseRequest(AssetAllocation assetAlloc) throws AssetException 
	{
		String qry = "INSERT INTO Asset_Allocation VALUES(seq_alloc_id.nextVal,?,?,?,?,'Pending',?)";
		int id=0;
		 try{
			 PreparedStatement pstmt = con.prepareStatement(qry);
			 pstmt.setInt(1, assetAlloc.getAssetId());
			 pstmt.setInt(2, assetAlloc.getEmpNo());
			 pstmt.setDate(3, assetAlloc.getAllocationDate());
			 pstmt.setDate(4, assetAlloc.getReleaseDate());
			 pstmt.setInt(5,assetAlloc.getQuantity());
			 int row = pstmt.executeUpdate();
			 if(row>0)
			 {
				 id=getAllocationId();
				 assetAlloc.setAllocationId(id);
				 
			 }
		
		 }
		 catch(Exception e)
		 {
			 throw new AssetException(e.getMessage());
		 }
			return id;
	}

	@Override
	public String checkStatus(int allocId) 
	{
		String st = null;
		String qry = "SELECT status FROM ASSET_ALLOCATION WHERE ALLOCATIONID=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, allocId);

			ResultSet rs =pstmt.executeQuery();
			while(rs.next())
			{
				st = rs.getString(1);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return st;
	}
	
	public int getAllocationId() throws AssetException
	{
		int id=0;
		String qry="SELECT seq_alloc_id.currval FROM DUAL";
		try{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			{
				id=rs.getInt(1);
			}
		}
		catch(Exception e)
		{
			throw new AssetException(e.getMessage());
		}
		return id;
	}

	@Override
	public ArrayList<Integer> displayAllAssetId()  
	{
		ArrayList<Integer> list = new ArrayList<Integer>();
		String qry = "SELECT ASSETID FROM ASSET";
		try 
		{
	
			PreparedStatement pstmt = con.prepareStatement(qry);
		    ResultSet rs = pstmt.executeQuery();
		    while(rs.next())
		    {
		    	list.add(rs.getInt(1));
		    }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return list;
	}
	
	@Override
	public ArrayList<Integer> displayAssetAllocationId() 
	{
		
		ArrayList<Integer> list = new ArrayList<Integer>();
		String qry = "SELECT ALLOCATIONID FROM ASSET_ALLOCATION";
		try 
		{
	
			PreparedStatement pstmt = con.prepareStatement(qry);
		    ResultSet rs = pstmt.executeQuery();
		    while(rs.next())
		    {
		    	list.add(rs.getInt(1));
		    }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return list;
	}
	
	@Override
	public ArrayList<Integer> displayAllEmpNo()  {
		ArrayList<Integer> list = new ArrayList<Integer>();
		String qry = "SELECT EMPNO FROM EMPLOYEE";
		try 
		{
	
			PreparedStatement pstmt = con.prepareStatement(qry);
		    ResultSet rs = pstmt.executeQuery();
		    while(rs.next())
		    {
		    	list.add(rs.getInt(1));
		    }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return list;
	}


	@Override
	public ArrayList<Asset> displayAllAssets() 
	{
		ArrayList<Asset> list = new ArrayList<Asset>();
		String qry = "SELECT * from asset";
		try 
		{
	
			Statement st=con.createStatement();
			
		    ResultSet rs = st.executeQuery(qry);
		    while(rs.next())
		    {
		    	Asset asset=new Asset(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getString(5));
		    	list.add(asset);
		    }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return list;
	}


	@Override
	public int getQuantity(int id) 
	{
		String qry="Select quantity from asset where assetid=?";
		int quantity=0;
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, id);

			ResultSet rs =pstmt.executeQuery();
			while(rs.next())
			{
				quantity = rs.getInt(1);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return quantity;
	}

	


}
