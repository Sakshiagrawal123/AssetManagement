package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Asset;
import com.cg.dto.AssetAllocation;
import com.cg.exception.AssetException;

public interface ManagerDAO 
{

	public int raiseRequest(AssetAllocation assetAlloc)throws AssetException;
	public String checkStatus(int allocId);
	public ArrayList<Integer> displayAssetAllocationId();
	public ArrayList<Integer> displayAllAssetId();
	public ArrayList<Integer> displayAllEmpNo();
	public ArrayList<Asset> displayAllAssets();
	public int getQuantity(int id);

}
