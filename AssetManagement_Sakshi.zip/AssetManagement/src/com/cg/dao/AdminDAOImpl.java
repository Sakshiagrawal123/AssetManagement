package com.cg.dao;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.dto.Asset;
import com.cg.dto.AssetAllocation;
import com.cg.dto.UserMaster;
import com.cg.exception.AssetException;
import com.cg.service.AdminServiceImpl;
import com.cg.util.DBUtil;

public class AdminDAOImpl implements AdminDAO {
	Connection con=null;
	Logger adminDAOLogger=null;
	
	public AdminDAOImpl()
	{
		con=DBUtil.getConnection();
		adminDAOLogger=Logger.getLogger(AdminServiceImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		
	}

	@Override
	public ArrayList<AssetAllocation> displayAllAssetRequest()
			throws AssetException
	{
		
		String qry = "SELECT * FROM asset_allocation order by  allocation_date";
		ArrayList<AssetAllocation>list = new ArrayList<AssetAllocation>();
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while(rs.next())
			{
				int allocationId = rs.getInt(1);
				int assetID=rs.getInt(2);
				int empNo=rs.getInt(3);
				Date allocationDate=rs.getDate(4);
				Date releaseDate=rs.getDate(5);
				String status=rs.getString(6);
				int quantity=rs.getInt(7);
				AssetAllocation asset=new AssetAllocation(allocationId,assetID,empNo,allocationDate,releaseDate,status,quantity);
				list.add(asset);
			}
		}
		catch(Exception e)
		{
			adminDAOLogger.error("Data retreival from asset_allocation tablle unsuccessful.Exception Occurred!!!");
			System.out.println(e.getMessage());
		}
		adminDAOLogger.info("All records from asset_allocation table retreived successfully!!!");
		return list;
	}

	@Override
	public UserMaster getUser(String userName, String userPassword) throws AssetException {
		String query = "Select * from user_master where username = ? and userpassword = ?";
		UserMaster user = null;
		try
		{
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, userName);
			pstmt.setString(2, userPassword);
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next())
			{
				user = new UserMaster(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
			}
			else
			{
				adminDAOLogger.info("Entered invalid username and password!!!");
				throw new AssetException ("Username/Password Invalid");
			}
			
		}
		catch (SQLException e)
		{
			adminDAOLogger.error("Exception occured while accessing user_master!!!");
			System.out.println(e.getMessage());
		}
		adminDAOLogger.info("Entered valid username and password.Returning user record!!!");
		return user;
	}
	public int getAllocationId() throws AssetException
	{
		int id=0;
		String qry="SELECT seq_alloc_id.currval FROM DUAL";
		try{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			{
				id=rs.getInt(1);
			}
		}
		catch(Exception e)
		{
			adminDAOLogger.error("Exception occured while accessing seq_alloc_id!!!");
			throw new AssetException(e.getMessage());
		}
		adminDAOLogger.info("Returning current value from set_alloc_id!!!");
		return id;
	}

	

	@Override
	public int addAsset(Asset asset) throws AssetException
	{
		
		String qry = "INSERT INTO Asset VALUES(asset_id.nextVal,?,?,?,?)";
		int row=0;
		try{
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setString(1,asset.getAssetName());
			pstmt.setString(2, asset.getAssetDesc());
			pstmt.setInt(3,asset.getQuantity());
			pstmt.setString(4,asset.getStatus());
			row = pstmt.executeUpdate();
			
		}
		catch(Exception e){
			adminDAOLogger.error("Exception occured while accessing seq_alloc_id!!!");
			e.printStackTrace();
		}
		adminDAOLogger.info("Returning next value from set_alloc_id!!!");
		return row;
	}

	@Override
	public int updateStatus(String str,int choice) throws AssetException
	{
		

		String qry="";
		String query="";
		String[] s;
		s=str.split(",");
		int[] arr=new int[s.length];
		for(int i=0;i<s.length;i++)
		{
			arr[i]=Integer.parseInt(s[i]);
		}
		
	
		if(choice==1)
		{
			qry="update  asset_allocation set status='Allocated' where allocationid=?";
			AssetAllocation asset=null;
			int assetID;
			int quantity1;
			for(int i=0;i<arr.length;i++)
			{
				
				asset=getAssetAlloc(arr[i]);
				assetID=asset.getAssetId();
				quantity1=asset.getQuantity();
				query="update asset set quantity=quantity-? where assetid=?";
				
				
				try 
				{
					PreparedStatement pstmt = con.prepareStatement(qry);
					PreparedStatement pstmt1 = con.prepareStatement(query);
					pstmt.setInt(1,arr[i]);
					
					pstmt.executeUpdate();
					pstmt1.setInt(1,quantity1);
					pstmt1.setInt(2, assetID);
					pstmt1.executeUpdate();
				} 
				catch (SQLException e) 
				{
					adminDAOLogger.error("Exception occured while accessing asset table!!!");
					System.out.println(e.getMessage());
				}
			}
		}
		else if(choice==2)
		{
			qry="update  asset_allocation set status='Unallocated' where allocationid=?";
			for(int i=0;i<arr.length;i++)
			{
				
				
				
				try 
				{
					PreparedStatement pstmt = con.prepareStatement(qry);
					pstmt.setInt(1,arr[i]);
					pstmt.executeUpdate();
				} 
				catch (SQLException e) 
				{
					adminDAOLogger.error("Exception occured while accessing asset_allocation table!!!");
					System.out.println(e.getMessage());
				}
			}
		}
		adminDAOLogger.info("Data updation successful!!!");
		return 0;
	}
	
	public AssetAllocation getAssetAlloc(int id)
	{
		String qry="select * from asset_allocation where allocationid=?";
		AssetAllocation asset=null;
		try
		{
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, id);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{
				asset=new AssetAllocation(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getDate(4),rs.getDate(5),rs.getString(6),rs.getInt(7));
			}
		}
		catch (SQLException e) 
		{
			adminDAOLogger.error("Exception occured while accessing asset_allocation table!!!");
			e.printStackTrace();
		}
		adminDAOLogger.info("Returning AssetAllocation record from asset_allocation table!!!");
		return asset;
	}

	@Override
	public int updateAsset(Asset asset) throws AssetException
	{
		int ref = 0;
		String query = "UPDATE asset set ASSETNAME=?, ASSETDES=?, QUANTITY=?, STATUS=? where ASSETID=?";
		try 
		{
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1,asset.getAssetName());
			pstmt.setString(2,asset.getAssetDesc());
			pstmt.setInt(3,asset.getQuantity());
			pstmt.setString(4,asset.getStatus());
			pstmt.setInt(5,asset.getAssetId());
			ref = pstmt.executeUpdate();
		} 
		catch (SQLException e) 
		{
			adminDAOLogger.error("Exception occured while accessing asset table!!!");
			System.out.println(e.getMessage());
		}
		adminDAOLogger.info("Data updation successful.Returning updated record!!!");
		return ref;
	}

	@Override
	public ArrayList<AssetAllocation> showRequestList(String str) throws AssetException 
	{
		String qry = "SELECT * FROM asset_allocation WHERE status=?";
		ArrayList<AssetAllocation>list = new ArrayList<AssetAllocation>();
		try
		{
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setString(1,str);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next())
			{
				int allocationId = rs.getInt(1);
				int assetID=rs.getInt(2);
				int empNo=rs.getInt(3);
				Date allocationDate=rs.getDate(4);
				Date releaseDate=rs.getDate(5);
				String status=rs.getString(6);
				int quantity=rs.getInt(7);
				AssetAllocation asset=new AssetAllocation(allocationId,assetID,empNo,allocationDate,releaseDate,status,quantity);
				list.add(asset);
			}
		}
		catch(Exception e)
		{
			adminDAOLogger.error("Exception occured while accessing asset_allocation table!!!");
			System.out.println(e.getMessage());
		}
		adminDAOLogger.info("Returning all request statuses from asset_allocation !!!");
		return list;
	}
	

	@Override
	public void exportAssetStatus() throws AssetException {
	
		 String qry = "SELECT * FROM ASSET_ALLOCATION";
		
		 try
		 {
			  Statement stmt1 = con.createStatement();
			  ResultSet rs = stmt1.executeQuery(qry);
			  ArrayList<AssetAllocation>list = new ArrayList<AssetAllocation>();
			  while(rs.next())
			  {
				  int allocationId = rs.getInt(1);
				  int assetID=rs.getInt(2);
				  int empNo=rs.getInt(3);
				  Date allocationDate=rs.getDate(4);
				  Date releaseDate=rs.getDate(5);
				  String status=rs.getString(6);
				  int quantity=rs.getInt(7);
				  AssetAllocation asset=new AssetAllocation(allocationId,assetID,empNo,allocationDate,releaseDate,status,quantity);
				  list.add(asset);
			  }
			 
	
			   FileWriter writer = new FileWriter("C:\\Users\\sagrawa5\\Desktop\\exportdata.csv");
			   List<String> test1 = new ArrayList<>();
			   test1.add("Allocation ID");
			   test1.add("Asset ID");
			   test1.add("Employee Number");
			   test1.add("Allocation Date");
			   test1.add("Release Date");
			   test1.add("Status");
			   test1.add("Quantity");
			   test1.add("\n");
	
			   String collectColName = test1.stream().collect(Collectors.joining(","));
			   writer.write(collectColName);
			   for(AssetAllocation aa : list)
			   {
				   List<String> test = new ArrayList<>();
				   Integer aId = new Integer (aa.getAllocationId());
				   test.add(aId.toString());
				   Integer asId = new Integer (aa.getAssetId());
				   test.add(asId.toString());
				   Integer empId = new Integer (aa.getEmpNo());
				   test.add(empId.toString());
				   test.add(aa.getAllocationDate().toString());
				   test.add(aa.getReleaseDate().toString());
				   test.add(aa.getAllocationStatus());
				   Integer quantity= new Integer (aa.getQuantity());
				   test.add(quantity.toString());
				   test.add("\n");
				   String collect = test.stream().collect(Collectors.joining(","));
				   writer.write(collect);
			   }
	
			   writer.close();

		 } 
		 catch (SQLException e) 
		 {
			 adminDAOLogger.error("SQL Exception occured while exporting!!!");
			 e.printStackTrace();
		 } 
		 catch (IOException e) 
		 {
			 adminDAOLogger.error("IO Exception occured while exporting!!!");
			 e.printStackTrace();
		
		 }
		 adminDAOLogger.info("Exporting successful!!!");
	}

	@Override
	public int updateQuantity() throws AssetException 
	{
		System.out.println("In update quantity");
		ArrayList<AssetAllocation> list=displayAllAssetRequest();
		for(AssetAllocation request:list)
		{
			
			LocalDate date2=LocalDate.now();
			Date releaseDate=Date.valueOf(date2);
			if(releaseDate.compareTo(request.getReleaseDate())>=0)
			{
				if(request.getAllocationStatus()=="Allocated")
				{
					String query="update asset set quantity=quantity+? where assetid=?";
					try 
					{
						PreparedStatement pst=con.prepareStatement(query);
						pst.setInt(1, request.getQuantity());
						pst.setInt(2, request.getAssetId());
						pst.executeUpdate();
					
					} 
					catch (SQLException e) 
					{
					
						e.printStackTrace();
					}
				}
				
			}
		}
		return 0;
	}

	@Override
	public ArrayList<Asset> displayAllAssets() 
	{
		ArrayList<Asset> list = new ArrayList<Asset>();
		String qry = "SELECT * from asset";
		try 
		{
	
			Statement st=con.createStatement();
			
		    ResultSet rs = st.executeQuery(qry);
		    while(rs.next())
		    {
		    	Asset asset=new Asset(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getString(5));
		    	list.add(asset);
		    }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return list;
	}

	
	
	

}
